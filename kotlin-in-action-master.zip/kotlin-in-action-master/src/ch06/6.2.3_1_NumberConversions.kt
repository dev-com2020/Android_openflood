package ch06.ex2_3_1_NumberConversions

fun main(args: Array<String>) {
    val x = 1
    println(x.toLong() in listOf(1L, 2L, 3L))
}
