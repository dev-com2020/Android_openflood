package ch06.ex2_3_3_NumberConversions2

fun main(args: Array<String>) {
    println("42".toInt())
}
