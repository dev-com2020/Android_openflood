package ch05.ex1_3_2_SyntaxForLambdaExpressions1

fun main(args: Array<String>) {
    { println(42) }()
}
